#!/bin/bash
# ════════════════════════════════════════════════════════════════════════════
#  apply_changes.sh — Codespace terminalinde çalıştır:
#    bash apply_changes.sh
#
#  Proje kök klasöründen çalıştırılmalı (build.gradle'ın olduğu yer)
# ════════════════════════════════════════════════════════════════════════════
set -e

# Modül adını otomatik bul (app veya başka bir şey olabilir)
MODULE=$(find . -maxdepth 2 -name "build.gradle" | grep -v "^\./build.gradle" | head -1 | cut -d/ -f2)
SRC="$MODULE/src/main"
KT="$SRC/java/com/voicerecorder"
RES="$SRC/res"

echo "📁 Modül: $MODULE"
echo "📁 Kaynak: $KT"

# ── Kotlin dosyaları ────────────────────────────────────────────────────────
echo ""
echo "▶ Kotlin dosyaları kopyalanıyor..."
cp RecordingService.kt   "$KT/RecordingService.kt"
cp RecordingAdapter.kt   "$KT/RecordingAdapter.kt"
cp RecorderWidget.kt     "$KT/RecorderWidget.kt"
echo "  ✓ RecordingService.kt  (telefon araması ses kaynağı + widget broadcast)"
echo "  ✓ RecordingAdapter.kt  (gelişmiş oynatıcı: hız, +10s/-10s, 200ms progress)"
echo "  ✓ RecorderWidget.kt    (yeni ana ekran widget'ı)"

# ── Layout dosyaları ────────────────────────────────────────────────────────
echo ""
echo "▶ Layout dosyaları kopyalanıyor..."
cp widget_recorder.xml "$RES/layout/widget_recorder.xml"
echo "  ✓ widget_recorder.xml → res/layout/"

# ── Drawable ────────────────────────────────────────────────────────────────
echo ""
echo "▶ Drawable dosyaları kopyalanıyor..."
cp widget_bg.xml "$RES/drawable/widget_bg.xml"
echo "  ✓ widget_bg.xml → res/drawable/"

# ── XML kaynakları (widget_info) ─────────────────────────────────────────────
echo ""
echo "▶ XML kaynakları kopyalanıyor..."
mkdir -p "$RES/xml"
cp widget_info.xml "$RES/xml/widget_info.xml"
echo "  ✓ widget_info.xml → res/xml/"

# ── AndroidManifest ─────────────────────────────────────────────────────────
echo ""
echo "▶ AndroidManifest.xml güncelleniyor..."
cp AndroidManifest.xml "$SRC/AndroidManifest.xml"
echo "  ✓ AndroidManifest.xml (widget receiver eklendi)"

# ── Detay layout kontrolü ────────────────────────────────────────────────────
echo ""
echo "⚠  MANUEL KONTROL GEREKLİ:"
echo "   activity_recording_detail.xml dosyasında şu ID'lerin VAR olduğundan emin ol:"
echo "   - @+id/btnRewind        (geri 10s butonu)"
echo "   - @+id/btnForward       (ileri 10s butonu)"
echo "   - @+id/btnSpeed         (MaterialButton — hız değiştirici)"
echo "   - @+id/tvTotalDurationLabel (toplam süre)"
echo ""
echo "   Bunlar yoksa önceki dark tema layout'undan (activity_recording_detail.xml)"
echo "   kopyaladığın dosyada zaten tanımlı."

# ── Build ────────────────────────────────────────────────────────────────────
echo ""
echo "▶ Gradle build başlatılıyor..."
./gradlew assembleDebug

echo ""
echo "════════════════════════════════════════════════"
echo "✅ Tamamlandı!"
echo "   APK: $MODULE/build/outputs/apk/debug/*.apk"
echo "════════════════════════════════════════════════"
