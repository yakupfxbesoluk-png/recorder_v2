package com.voicerecorder

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File

data class Recording(
    val id: Long = 0,
    val title: String,
    val filePath: String,
    val duration: Long,
    val timestamp: Long,
    val fileSize: Long
)

class RecordingDatabase(context: Context) :
    SQLiteOpenHelper(context, "recordings.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE recordings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                file_path TEXT NOT NULL,
                duration INTEGER NOT NULL,
                timestamp INTEGER NOT NULL,
                file_size INTEGER NOT NULL
            )
        """)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS recordings")
        onCreate(db)
    }
}

class RecordingRepository(context: Context) {

    private val db = RecordingDatabase(context).writableDatabase

    fun insertRecording(recording: Recording): Long {
        val values = ContentValues().apply {
            put("title", recording.title)
            put("file_path", recording.filePath)
            put("duration", recording.duration)
            put("timestamp", recording.timestamp)
            put("file_size", recording.fileSize)
        }
        return db.insert("recordings", null, values)
    }

    fun getAllRecordings(): List<Recording> {
        val list = mutableListOf<Recording>()
        val cursor = db.query("recordings", null, null, null, null, null, "timestamp DESC")
        cursor.use {
            while (it.moveToNext()) {
                list.add(
                    Recording(
                        id = it.getLong(it.getColumnIndexOrThrow("id")),
                        title = it.getString(it.getColumnIndexOrThrow("title")),
                        filePath = it.getString(it.getColumnIndexOrThrow("file_path")),
                        duration = it.getLong(it.getColumnIndexOrThrow("duration")),
                        timestamp = it.getLong(it.getColumnIndexOrThrow("timestamp")),
                        fileSize = it.getLong(it.getColumnIndexOrThrow("file_size"))
                    )
                )
            }
        }
        return list
    }

    fun getRecordingById(id: Long): Recording? {
        val cursor = db.query("recordings", null, "id=?", arrayOf(id.toString()), null, null, null)
        return cursor.use {
            if (it.moveToFirst()) Recording(
                id = it.getLong(it.getColumnIndexOrThrow("id")),
                title = it.getString(it.getColumnIndexOrThrow("title")),
                filePath = it.getString(it.getColumnIndexOrThrow("file_path")),
                duration = it.getLong(it.getColumnIndexOrThrow("duration")),
                timestamp = it.getLong(it.getColumnIndexOrThrow("timestamp")),
                fileSize = it.getLong(it.getColumnIndexOrThrow("file_size"))
            ) else null
        }
    }

    fun renameRecording(id: Long, newTitle: String) {
        val values = ContentValues().apply { put("title", newTitle) }
        db.update("recordings", values, "id=?", arrayOf(id.toString()))
    }

    fun deleteRecording(recording: Recording) {
        db.delete("recordings", "id=?", arrayOf(recording.id.toString()))
        File(recording.filePath).delete()
    }

    fun deleteAllRecordings() {
        val cursor = db.query("recordings", arrayOf("file_path"), null, null, null, null, null)
        cursor.use {
            while (it.moveToNext()) File(it.getString(0)).delete()
        }
        db.delete("recordings", null, null)
    }
}
