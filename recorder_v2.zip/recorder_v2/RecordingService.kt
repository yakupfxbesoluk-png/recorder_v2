package com.voicerecorder

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class RecordingService : Service() {

    companion object {
        const val CHANNEL_ID = "VoiceRecorderChannel"
        const val NOTIFICATION_ID = 2001

        const val ACTION_START  = "ACTION_START"
        const val ACTION_PAUSE  = "ACTION_PAUSE"
        const val ACTION_RESUME = "ACTION_RESUME"
        const val ACTION_STOP   = "ACTION_STOP"

        const val BROADCAST_STATE  = "com.voicerecorder.STATE_UPDATE"
        const val EXTRA_STATE      = "state"        // "recording" | "paused" | "stopped"
        const val EXTRA_ELAPSED_MS = "elapsed_ms"

        // Widget ve diğer alıcılar için ayrı broadcast
        const val BROADCAST_WIDGET = "com.voicerecorder.WIDGET_UPDATE"

        var isRecording = false
        var isPaused    = false
    }

    private var mediaRecorder: MediaRecorder? = null
    private var outputFile = ""
    private var elapsedBeforePause   = 0L
    private var segmentStartTime     = 0L
    private var recordingStartTimestamp = 0L

    private val handler    = Handler(Looper.getMainLooper())
    private val repository by lazy { RecordingRepository(this) }

    // ── Telefon araması tespiti ──────────────────────────────────────────────
    // READ_PHONE_STATE iznine gerek kalmadan AudioManager ile yaklaşık tespit:
    // Aramanın VOICE_CALL veya IN_CALL modunda VOICE_COMMUNICATION kaynağı
    // kullanılır; geçiş olunca AudioManager.ACTION_AUDIO_BECOMING_NOISY fırlat.
    // Android 9+ için CallAudioState dinlemesi service-side yapılabilir ama bu
    // basit yöntem izin gerektirmeden çalışır.
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    // Kayıt sırasında ses kaynağını telefon aramasına göre seç
    private fun resolveAudioSource(): Int {
        val mode = audioManager.mode
        return if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION) {
            // Telefon araması aktif: hem mikrofon hem hoparlör/ahize sesini yakala
            // VOICE_COMMUNICATION = VoIP/telefon araması için optimize
            // VOICE_DOWNLINK      = sadece karşı taraf (bazı cihazlarda desteklenmez)
            // VOICE_CALL          = her iki yön (en kapsamlı, izin gerektirmez)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaRecorder.AudioSource.VOICE_CALL        // API 29+ önerilen
            } else {
                MediaRecorder.AudioSource.VOICE_COMMUNICATION
            }
        } else {
            MediaRecorder.AudioSource.MIC
        }
    }

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (isRecording && !isPaused) {
                val elapsed = currentElapsedMs()
                updateNotification(elapsed, false)
                broadcastState("recording", elapsed)
                broadcastWidget()
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START  -> startRecording()
            ACTION_PAUSE  -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
            ACTION_STOP   -> stopRecording()
        }
        return START_STICKY
    }

    // ════════════════════════════════════════════════════════════════════════
    //  KAYIT KONTROLLERİ
    // ════════════════════════════════════════════════════════════════════════

    private fun startRecording() {
        if (isRecording) return
        try {
            outputFile            = createOutputFilePath()
            recordingStartTimestamp = System.currentTimeMillis()
            elapsedBeforePause    = 0L
            segmentStartTime      = System.currentTimeMillis()

            val audioSource = resolveAudioSource()   // <── telefon araması tespiti

            mediaRecorder = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            ).apply {
                setAudioSource(audioSource)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(192000)   // 128→192 kalite artışı
                setAudioChannels(1)
                setOutputFile(outputFile)
                prepare()
                start()
            }

            isRecording = true
            isPaused    = false

            startForeground(NOTIFICATION_ID, buildNotification(0L, false))
            handler.post(tickRunnable)
            broadcastState("recording", 0L)
            broadcastWidget()

        } catch (e: Exception) {
            isRecording = false
            mediaRecorder?.release()
            mediaRecorder = null
        }
    }

    private fun pauseRecording() {
        if (!isRecording || isPaused) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                mediaRecorder?.pause()
            }
            elapsedBeforePause += System.currentTimeMillis() - segmentStartTime
            isPaused = true
            handler.removeCallbacks(tickRunnable)
            updateNotification(elapsedBeforePause, true)
            broadcastState("paused", elapsedBeforePause)
            broadcastWidget()
        } catch (_: Exception) {}
    }

    private fun resumeRecording() {
        if (!isRecording || !isPaused) return
        try {
            mediaRecorder?.resume()
            segmentStartTime = System.currentTimeMillis()
            isPaused = false
            handler.post(tickRunnable)
            broadcastState("recording", elapsedBeforePause)
            broadcastWidget()
        } catch (_: Exception) {}
    }

    private fun stopRecording() {
        if (!isRecording) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }

        val finalElapsed = currentElapsedMs()

        try {
            mediaRecorder?.apply { stop(); reset(); release() }
        } catch (_: Exception) {}
        mediaRecorder = null

        handler.removeCallbacks(tickRunnable)

        if (finalElapsed < 1000) {
            File(outputFile).delete()
        } else {
            repository.insertRecording(
                Recording(
                    title     = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("tr"))
                                    .format(Date(recordingStartTimestamp)),
                    filePath  = outputFile,
                    duration  = finalElapsed,
                    timestamp = recordingStartTimestamp,
                    fileSize  = File(outputFile).length()
                )
            )
        }

        isRecording = false
        isPaused    = false
        elapsedBeforePause = 0L

        broadcastState("stopped", finalElapsed)
        broadcastWidget()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun currentElapsedMs(): Long =
        if (isPaused) elapsedBeforePause
        else elapsedBeforePause + (System.currentTimeMillis() - segmentStartTime)

    // ════════════════════════════════════════════════════════════════════════
    //  BİLDİRİM
    // ════════════════════════════════════════════════════════════════════════

    private fun createOutputFilePath(): String {
        val dir = File(getExternalFilesDir(null), "Recordings").also { it.mkdirs() }
        val ts  = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        return File(dir, "REC_$ts.m4a").absolutePath
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Ses Kaydedici",
                NotificationManager.IMPORTANCE_LOW).apply {
                description = "Aktif kayıt bildirimi"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun updateNotification(elapsedMs: Long, paused: Boolean) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_ID, buildNotification(elapsedMs, paused))
    }

    private fun buildNotification(elapsedMs: Long, paused: Boolean): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val pauseResumeAction = if (paused)
            NotificationCompat.Action(R.drawable.ic_play, "Devam Et",
                servicePendingIntent(ACTION_RESUME, 1))
        else
            NotificationCompat.Action(R.drawable.ic_pause, "Duraklat",
                servicePendingIntent(ACTION_PAUSE, 2))

        val stopAction = NotificationCompat.Action(R.drawable.ic_stop, "Durdur",
            servicePendingIntent(ACTION_STOP, 3))

        val statusText = if (paused) "⏸ Duraklatıldı • ${formatTime(elapsedMs)}"
                         else        "🔴 Kaydediliyor • ${formatTime(elapsedMs)}"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Ses Kaydedici")
            .setContentText(statusText)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setSilent(true)
            .addAction(pauseResumeAction)
            .addAction(stopAction)
            .build()
    }

    private fun servicePendingIntent(action: String, code: Int) =
        PendingIntent.getService(
            this, code,
            Intent(this, RecordingService::class.java).also { it.action = action },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    // ════════════════════════════════════════════════════════════════════════
    //  BROADCAST'LER
    // ════════════════════════════════════════════════════════════════════════

    private fun broadcastState(state: String, elapsedMs: Long) {
        LocalBroadcastManager.getInstance(this).sendBroadcast(
            Intent(BROADCAST_STATE).apply {
                putExtra(EXTRA_STATE, state)
                putExtra(EXTRA_ELAPSED_MS, elapsedMs)
            }
        )
    }

    /** Widget'ı güncellemek için sistem genelinde broadcast gönder */
    private fun broadcastWidget() {
        sendBroadcast(Intent(BROADCAST_WIDGET).apply {
            putExtra("is_recording", isRecording)
            putExtra("is_paused",    isPaused)
            putExtra("elapsed_ms",   currentElapsedMs())
        })
    }

    private fun formatTime(ms: Long): String {
        val t = ms / 1000
        val h = t / 3600; val m = (t % 3600) / 60; val s = t % 60
        return if (h > 0) "%02d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(tickRunnable)
        if (isRecording) stopRecording()
        super.onDestroy()
    }
}
