package com.voicerecorder

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.voicerecorder.databinding.ActivityRecordingDetailBinding
import com.voicerecorder.databinding.ItemRecordingBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

// ════════════════════════════════════════════════════════════════════════════
//  ADAPTER
// ════════════════════════════════════════════════════════════════════════════
class RecordingAdapter(
    private val onItemClick:   (Recording) -> Unit,
    private val onDeleteClick: (Recording) -> Unit
) : ListAdapter<Recording, RecordingAdapter.ViewHolder>(DiffCallback()) {

    class ViewHolder(val binding: ItemRecordingBinding) :
        RecyclerView.ViewHolder(binding.root)

    class DiffCallback : DiffUtil.ItemCallback<Recording>() {
        override fun areItemsTheSame(old: Recording, new: Recording) = old.id == new.id
        override fun areContentsTheSame(old: Recording, new: Recording) = old == new
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemRecordingBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val rec = getItem(position)
        holder.binding.apply {
            tvTitle.text    = rec.title
            tvDuration.text = formatDuration(rec.duration)
            tvDate.text     = SimpleDateFormat("dd MMM yyyy HH:mm", Locale("tr"))
                                  .format(Date(rec.timestamp))
            tvFileSize.text = formatFileSize(rec.fileSize)
            root.setOnClickListener { onItemClick(rec) }
            btnDelete.setOnClickListener { onDeleteClick(rec) }
        }
    }

    private fun formatDuration(ms: Long): String {
        val m = (ms / 1000) / 60; val s = (ms / 1000) % 60
        return "%02d:%02d".format(m, s)
    }
    private fun formatFileSize(bytes: Long) = when {
        bytes < 1024       -> "$bytes B"
        bytes < 1_048_576  -> "${bytes / 1024} KB"
        else               -> "%.1f MB".format(bytes / 1_048_576.0)
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  DETAY / OYNATICI  — gelişmiş sürüm
// ════════════════════════════════════════════════════════════════════════════
class RecordingDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRecordingDetailBinding
    private var mediaPlayer: MediaPlayer? = null
    private var isPlaying = false
    private var currentSpeed = 1.0f                          // oynatma hızı
    private val SPEEDS = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)

    private val progressHandler = Handler(Looper.getMainLooper())
    private val repository by lazy { RecordingRepository(this) }
    private var recording: Recording? = null

    // ── Yaşam döngüsü ────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecordingDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Kayıt"

        val id = intent.getLongExtra("recording_id", -1)
        recording = repository.getRecordingById(id)
        recording?.let { bindUI(it) } ?: finish()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed(); return true
    }

    override fun onDestroy() { releasePlayer(); super.onDestroy() }

    // ── UI bağlantısı ────────────────────────────────────────────────────

    private fun bindUI(rec: Recording) {
        binding.apply {
            tvDetailTitle.text  = rec.title
            tvDetailDate.text   = SimpleDateFormat("dd MMMM yyyy, HH:mm:ss", Locale("tr"))
                                      .format(Date(rec.timestamp))
            tvDetailSize.text   = formatFileSize(rec.fileSize)
            tvTotalDurationLabel.text = formatDuration(rec.duration)
            tvTotalTime.text    = formatDuration(rec.duration)

            // Oynat / duraklat
            btnPlayPause.setOnClickListener { togglePlayback(rec) }

            // Yeniden adlandır
            btnRename.setOnClickListener { showRenameDialog(rec) }

            // Paylaş
            btnShare.setOnClickListener { shareRecording(rec) }

            // ── Geri / ileri 10 sn ──────────────────────────────────────
            // Bu butonlar activity_recording_detail.xml'de tanımlı:
            //   android:id="@+id/btnRewind"   (geri 10s)
            //   android:id="@+id/btnForward"  (ileri 10s)
            // Eğer önceki layout'unda bu ID'ler yoksa eklemen gerekir.
            btnRewind.setOnClickListener {
                mediaPlayer?.let { mp ->
                    val pos = (mp.currentPosition - 10_000).coerceAtLeast(0)
                    mp.seekTo(pos)
                    binding.seekBar.progress = pos
                    binding.tvCurrentTime.text = formatDuration(pos.toLong())
                }
            }
            btnForward.setOnClickListener {
                mediaPlayer?.let { mp ->
                    val pos = (mp.currentPosition + 10_000).coerceAtMost(mp.duration)
                    mp.seekTo(pos)
                    binding.seekBar.progress = pos
                    binding.tvCurrentTime.text = formatDuration(pos.toLong())
                }
            }

            // ── Hız butonu ───────────────────────────────────────────────
            // Layout'ta: android:id="@+id/btnSpeed"  (MaterialButton)
            btnSpeed.setOnClickListener { cycleSpeed() }
            btnSpeed.text = "1.0×"

            // ── SeekBar ─────────────────────────────────────────────────
            seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        mediaPlayer?.seekTo(progress)
                        binding.tvCurrentTime.text = formatDuration(progress.toLong())
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar) {
                    progressHandler.removeCallbacksAndMessages(null)
                }
                override fun onStopTrackingTouch(sb: SeekBar) {
                    if (isPlaying) scheduleProgress()
                }
            })
        }
    }

    // ── Oynatma ──────────────────────────────────────────────────────────

    private fun togglePlayback(rec: Recording) {
        if (!File(rec.filePath).exists()) {
            Toast.makeText(this, "Dosya bulunamadı", Toast.LENGTH_SHORT).show()
            return
        }
        if (isPlaying) pausePlayback() else startPlayback(rec)
    }

    private fun startPlayback(rec: Recording) {
        try {
            if (mediaPlayer == null) {
                mediaPlayer = MediaPlayer().apply {
                    setDataSource(rec.filePath)
                    prepare()
                    binding.seekBar.max = duration
                    binding.tvTotalTime.text = formatDuration(duration.toLong())
                    setOnCompletionListener { stopPlayback() }
                }
                applySpeed()                        // ilk açılışta hızı uygula
            }
            mediaPlayer?.start()
            isPlaying = true
            binding.btnPlayPause.setImageResource(R.drawable.ic_pause)
            scheduleProgress()
        } catch (e: Exception) {
            Toast.makeText(this, "Oynatılamadı: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pausePlayback() {
        mediaPlayer?.pause()
        isPlaying = false
        binding.btnPlayPause.setImageResource(R.drawable.ic_play)
        progressHandler.removeCallbacksAndMessages(null)
    }

    private fun stopPlayback() {
        releasePlayer()
        binding.btnPlayPause.setImageResource(R.drawable.ic_play)
        binding.seekBar.progress = 0
        binding.tvCurrentTime.text = "00:00"
    }

    private fun releasePlayer() {
        progressHandler.removeCallbacksAndMessages(null)
        mediaPlayer?.release()
        mediaPlayer = null
        isPlaying = false
    }

    // ── Sürekli progress güncellemesi (500ms → 200ms daha akıcı) ─────────

    private fun scheduleProgress() {
        progressHandler.postDelayed({
            mediaPlayer?.let { mp ->
                if (mp.isPlaying) {
                    val pos = mp.currentPosition
                    binding.seekBar.progress     = pos
                    binding.tvCurrentTime.text   = formatDuration(pos.toLong())
                    scheduleProgress()
                }
            }
        }, 200)                                     // 200ms → daha pürüzsüz
    }

    // ── Hız kontrolü (API 23+) ────────────────────────────────────────────

    private fun cycleSpeed() {
        val idx   = SPEEDS.indexOfFirst { it == currentSpeed }.takeIf { it >= 0 } ?: 2
        val next  = SPEEDS[(idx + 1) % SPEEDS.size]
        currentSpeed = next
        applySpeed()
        val label = if (next == next.toLong().toFloat()) "%.0f×".format(next)
                    else "%.2g×".format(next)
        binding.btnSpeed.text = label
    }

    private fun applySpeed() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            mediaPlayer?.playbackParams = mediaPlayer?.playbackParams
                ?.setSpeed(currentSpeed) ?: return
        }
    }

    // ── Rename / Share ────────────────────────────────────────────────────

    private fun showRenameDialog(rec: Recording) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            setText(rec.title); setSelection(text.length)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Kaydı Yeniden Adlandır")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) {
                    repository.renameRecording(rec.id, t)
                    binding.tvDetailTitle.text = t
                }
            }
            .setNegativeButton("İptal", null).show()
    }

    private fun shareRecording(rec: Recording) {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            this, "$packageName.fileprovider", File(rec.filePath)
        )
        startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = "audio/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "Kaydı Paylaş"
        ))
    }

    // ── Yardımcılar ───────────────────────────────────────────────────────

    private fun formatDuration(ms: Long): String {
        val m = (ms / 1000) / 60; val s = (ms / 1000) % 60
        return "%02d:%02d".format(m, s)
    }
    private fun formatFileSize(bytes: Long) = when {
        bytes < 1024      -> "$bytes B"
        bytes < 1_048_576 -> "${bytes / 1024} KB"
        else              -> "%.1f MB".format(bytes / 1_048_576.0)
    }
}
