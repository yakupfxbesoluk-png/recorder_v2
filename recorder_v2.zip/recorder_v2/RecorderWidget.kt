package com.voicerecorder

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/**
 * Ana ekran widget'ı.
 *
 * Gösterir: durum (Kayıt/Duraklatıldı/Hazır) + süre
 * Butonlar: Başlat/Duraklat/Devam/Durdur
 *
 * Layout dosyası: res/layout/widget_recorder.xml  (aşağıda tanımlı)
 */
class RecorderWidget : AppWidgetProvider() {

    companion object {
        /** Servis tüm widget'ları güncellemek için bu metodu çağırır */
        fun updateAll(context: Context) {
            val mgr      = AppWidgetManager.getInstance(context)
            val ids      = mgr.getAppWidgetIds(
                ComponentName(context, RecorderWidget::class.java)
            )
            if (ids.isEmpty()) return

            val views    = buildViews(context)
            mgr.updateAppWidget(ids, views)
        }

        private fun buildViews(context: Context): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_recorder)

            val isRec    = RecordingService.isRecording
            val isPaused = RecordingService.isPaused

            // ── Durum metni ──────────────────────────────────────────────
            val statusText = when {
                isRec && !isPaused -> "🔴 Kaydediliyor"
                isRec && isPaused  -> "⏸ Duraklatıldı"
                else               -> "🎙 Hazır"
            }
            views.setTextViewText(R.id.widget_status, statusText)

            // ── Buton görünürlüğü ────────────────────────────────────────
            // Başlat butonu: sadece kayıt YOK iken
            views.setViewVisibility(
                R.id.widget_btn_start,
                if (!isRec) android.view.View.VISIBLE else android.view.View.GONE
            )
            // Duraklat/Devam: kayıt VAR iken
            views.setViewVisibility(
                R.id.widget_btn_pause_resume,
                if (isRec) android.view.View.VISIBLE else android.view.View.GONE
            )
            views.setTextViewText(
                R.id.widget_btn_pause_resume,
                if (isPaused) "▶" else "⏸"
            )
            // Durdur: kayıt VAR iken
            views.setViewVisibility(
                R.id.widget_btn_stop,
                if (isRec) android.view.View.VISIBLE else android.view.View.GONE
            )

            // ── Buton intent'leri ─────────────────────────────────────────

            fun serviceIntent(action: String, reqCode: Int): PendingIntent {
                val i = Intent(context, RecordingService::class.java).also { it.action = action }
                return PendingIntent.getService(
                    context, reqCode, i,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            }

            views.setOnClickPendingIntent(R.id.widget_btn_start,
                serviceIntent(RecordingService.ACTION_START, 10))

            views.setOnClickPendingIntent(R.id.widget_btn_pause_resume,
                if (isPaused) serviceIntent(RecordingService.ACTION_RESUME, 11)
                else          serviceIntent(RecordingService.ACTION_PAUSE,  12))

            views.setOnClickPendingIntent(R.id.widget_btn_stop,
                serviceIntent(RecordingService.ACTION_STOP, 13))

            // ── Uygulamayı aç (widget'a tıklayınca) ─────────────────────
            val openApp = PendingIntent.getActivity(
                context, 20,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, openApp)

            return views
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val views = buildViews(context)
        appWidgetIds.forEach { appWidgetManager.updateAppWidget(it, views) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        // Servis'ten gelen WIDGET broadcast'ını yakala
        if (intent.action == RecordingService.BROADCAST_WIDGET) {
            updateAll(context)
        }
    }
}
